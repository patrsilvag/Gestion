import React from "react";
export default function CompromisoNuevo() {
  return (
    <div className="space-y-3">
      <h2 className="text-2xl font-semibold">Nuevo Compromiso</h2>
      <div className="text-sm text-muted-foreground">Ruta: /compromisos/nuevo</div>
    </div>
  );
}
