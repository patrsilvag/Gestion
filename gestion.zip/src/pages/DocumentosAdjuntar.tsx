import React from "react";
export default function DocumentosAdjuntar() {
  return (
    <div className="space-y-3">
      <h2 className="text-2xl font-semibold">Adjuntar Documentos</h2>
      <div className="text-sm text-muted-foreground">Ruta: /documentos/adjuntar</div>
    </div>
  );
}
