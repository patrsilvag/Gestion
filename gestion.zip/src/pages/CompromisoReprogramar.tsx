import React from "react";
export default function CompromisoReprogramar() {
  return (
    <div className="space-y-3">
      <h2 className="text-2xl font-semibold">Reprogramar Compromiso</h2>
      <div className="text-sm text-muted-foreground">Ruta: /compromisos/:id/reprogramar</div>
    </div>
  );
}
