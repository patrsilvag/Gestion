import React from "react";
export default function Mantenedores() {
  return (
    <div className="space-y-3">
      <h2 className="text-2xl font-semibold">Mantenedores</h2>
      <div className="text-sm text-muted-foreground">Configurar maestros y parámetros</div>
    </div>
  );
}
