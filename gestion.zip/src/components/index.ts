export { default as TableroOperativo } from "../pages/TableroOperativo";
