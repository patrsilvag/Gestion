import React from "react";
export default function Reportes() {
  return (
    <div className="space-y-3">
      <h2 className="text-2xl font-semibold">Reportes</h2>
      <div className="text-sm text-muted-foreground">Ruta: /reportes</div>
    </div>
  );
}
