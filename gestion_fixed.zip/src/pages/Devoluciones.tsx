import React from "react";
export default function Devoluciones() {
  return (
    <div className="space-y-3">
      <h2 className="text-2xl font-semibold">Devoluciones y Notas de Crédito</h2>
      <div className="text-sm text-muted-foreground">Ruta: /devoluciones</div>
    </div>
  );
}
