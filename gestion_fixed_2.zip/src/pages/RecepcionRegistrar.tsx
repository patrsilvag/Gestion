import React from "react";
export default function RecepcionRegistrar() {
  return (
    <div className="space-y-3">
      <h2 className="text-2xl font-semibold">Registrar Recepción</h2>
      <div className="text-sm text-muted-foreground">Ruta: /recepciones/registrar</div>
    </div>
  );
}
