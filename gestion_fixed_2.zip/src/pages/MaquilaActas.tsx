import React from "react";
export default function MaquilaActas() {
  return (
    <div className="space-y-3">
      <h2 className="text-2xl font-semibold">Actas de Maquila</h2>
      <div className="text-sm text-muted-foreground">Ruta: /maquila/actas</div>
    </div>
  );
}
